
using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class CharacterSelection : MonoBehaviour
{
    [System.Serializable]
    public class Hero
    {
        public string name;
        [TextArea(2, 3)] public string description;
        public Sprite icon;
        public Vector2 iconSize = new Vector2(100, 100);
    }

    [System.Serializable]
    public class HeroCard
    {
        public Image icon;
        public TMP_Text nameText;
    }

    [Header("Heroes")]
    [SerializeField] private Hero[] heroes;
    [SerializeField] private int selectedHero = 1;

    [Header("Cards")]
    [SerializeField] private HeroCard leftCard;
    [SerializeField] private HeroCard centerCard;
    [SerializeField] private HeroCard rightCard;

    [Header("Description")]
    [SerializeField] private TMP_Text characterTitle;
    [SerializeField] private TMP_Text descriptionText;

    [Header("Animation")]
    [SerializeField] private float fadeDuration = 0.15f;
    [SerializeField] private float sceneFadeDuration = 0.6f;
    [SerializeField] private CanvasGroup screenFade;

    [Header("Scene")]
    [SerializeField] private string nextScene = "TestLevel1";

    private CanvasGroup[] fadeGroups;
    private Coroutine fadeRoutine;
    private Coroutine screenFadeRoutine;
    private bool transitioning;
    private int displayedHero;

    private void Awake()
    {
        fadeGroups = new CanvasGroup[]
        {
            GetGroup(leftCard.icon.gameObject),
            GetGroup(leftCard.nameText.gameObject),
            GetGroup(centerCard.icon.gameObject),
            GetGroup(centerCard.nameText.gameObject),
            GetGroup(rightCard.icon.gameObject),
            GetGroup(rightCard.nameText.gameObject),
            GetGroup(characterTitle.gameObject),
            GetGroup(descriptionText.gameObject)
        };

        screenFade.alpha = 1f;
        screenFade.blocksRaycasts = true;
    }

    private void Start()
    {
        if (heroes.Length == 0)
            return;

        selectedHero = Mathf.Clamp(selectedHero, 0, heroes.Length - 1);
        UpdateDisplay();

        screenFadeRoutine = StartCoroutine(FadeScreen(1f, 0f));
    }

    private void Update()
    {
        if (heroes.Length == 0 || transitioning)
            return;

        if (Input.GetKeyDown(KeyCode.LeftArrow))
            PreviousHero();

        if (Input.GetKeyDown(KeyCode.RightArrow))
            NextHero();

        if (Input.GetKeyDown(KeyCode.Return) ||
            Input.GetKeyDown(KeyCode.KeypadEnter))
        {
            ConfirmHero();
        }
    }

    public void NextHero()
    {
        ChangeHero(1);
    }

    public void PreviousHero()
    {
        ChangeHero(-1);
    }

    private void ChangeHero(int direction)
    {
        if (heroes.Length == 0 || transitioning)
            return;

        selectedHero = (selectedHero + direction + heroes.Length) % heroes.Length;

        if (fadeRoutine != null)
            StopCoroutine(fadeRoutine);

        fadeRoutine = StartCoroutine(FadeCards());
    }

    private IEnumerator FadeCards()
    {
        float time = 0f;

        while (time < fadeDuration)
        {
            time += Time.deltaTime;
            SetAlpha(1f - Mathf.Clamp01(time / fadeDuration));
            yield return null;
        }

        SetAlpha(0f);
        UpdateDisplay();

        time = 0f;

        while (time < fadeDuration)
        {
            time += Time.deltaTime;
            SetAlpha(Mathf.Clamp01(time / fadeDuration));
            yield return null;
        }

        SetAlpha(1f);
        fadeRoutine = null;
    }

    public void ConfirmHero()
    {
        if (transitioning || heroes.Length == 0)
            return;

        transitioning = true;

        if (fadeRoutine != null)
        {
            StopCoroutine(fadeRoutine);
            fadeRoutine = null;
        }

        if (screenFadeRoutine != null)
            StopCoroutine(screenFadeRoutine);

        // Confirm the character currently on screen.
        selectedHero = displayedHero;
        UpdateDisplay();
        SetAlpha(1f);

        StartCoroutine(LoadSelectedHero());
    }

    private IEnumerator LoadSelectedHero()
    {
        PlayerPrefs.SetInt("SelectedHero", selectedHero);
        PlayerPrefs.SetString("SelectedHeroName", heroes[selectedHero].name);
        PlayerPrefs.Save();

        yield return StartCoroutine(FadeScreen(screenFade.alpha, 1f));

        SceneManager.LoadScene(nextScene);
    }

    private IEnumerator FadeScreen(float start, float end)
    {
        screenFade.blocksRaycasts = true;

        float time = 0f;

        while (time < sceneFadeDuration)
        {
            time += Time.unscaledDeltaTime;
            screenFade.alpha = Mathf.Lerp(
                start,
                end,
                Mathf.Clamp01(time / sceneFadeDuration)
            );

            yield return null;
        }

        screenFade.alpha = end;

        if (end == 0f)
            screenFade.blocksRaycasts = false;

        screenFadeRoutine = null;
    }

    private void UpdateDisplay()
    {
        displayedHero = selectedHero;

        int left = (selectedHero - 1 + heroes.Length) % heroes.Length;
        int right = (selectedHero + 1) % heroes.Length;

        UpdateCard(leftCard, heroes[left]);
        UpdateCard(centerCard, heroes[selectedHero]);
        UpdateCard(rightCard, heroes[right]);

        characterTitle.text = heroes[selectedHero].name.ToUpper();
        descriptionText.text = heroes[selectedHero].description;
    }

    private void UpdateCard(HeroCard card, Hero hero)
    {
        card.icon.sprite = hero.icon;
        card.icon.preserveAspect = true;
        card.icon.rectTransform.sizeDelta = hero.iconSize;
        card.nameText.text = hero.name.ToUpper();
    }

    private CanvasGroup GetGroup(GameObject obj)
    {
        CanvasGroup group = obj.GetComponent<CanvasGroup>();

        if (group == null)
            group = obj.AddComponent<CanvasGroup>();

        return group;
    }

    private void SetAlpha(float alpha)
    {
        foreach (CanvasGroup group in fadeGroups)
            group.alpha = alpha;
    }
}

using UnityEngine;
using Leap;

public class LeapGestureControls : MonoBehaviour
{
    [Header("References")]
    [SerializeField] private LeapProvider leapProvider;
    [SerializeField] private CharacterSelection characterSelection;

    [Header("Horizontal Swipe")]
    [SerializeField] private float swipeDistance = 0.07f;
    [SerializeField] private float swipeTime = 0.7f;
    [SerializeField] private float cooldown = 1f;

    [Header("Downward Confirmation")]
    [SerializeField] private float downSwipeDistance = 0.05f;
    [SerializeField] private float downSwipeSpeed = 0.3f;
    [SerializeField] private float downPauseTolerance = 0.1f;
    [SerializeField] private float settleAfterSwipe = 0.3f;
    [SerializeField] private float directionThreshold = 1.1f;

    [Header("Tracking")]
    [SerializeField] private float smoothing = 20f;
    [SerializeField] private float lostHandGrace = 0.2f;

    private Vector3 smoothPosition;
    private Vector3 startPosition;
    private Vector3 downStartPosition;

    private float startTime;
    private float lastSwipeTime = -10f;
    private float lastSeenTime = -10f;
    private float lastFallingTime = -10f;

    private bool handActive;
    private bool trackingHand;
    private bool movingDown;
    private bool confirmed;
    private int trackedHandId = -1;

    private void Update()
    {
        if (leapProvider == null || characterSelection == null || confirmed)
            return;

        Hand hand = GetHand(leapProvider.CurrentFrame);

        if (hand == null)
        {
            if (!handActive)
                return;

            // Allow brief tracking interruptions before resetting.
            if (Time.time - lastSeenTime > lostHandGrace)
            {
                handActive = false;
                trackingHand = false;
                movingDown = false;
                trackedHandId = -1;
            }
            else if (movingDown)
            {
                lastFallingTime = Time.time;
            }

            return;
        }

        Vector3 position = hand.PalmPosition;
        trackedHandId = hand.Id;
        lastSeenTime = Time.time;

        if (!handActive)
        {
            handActive = true;
            smoothPosition = position;
            startPosition = position;
            downStartPosition = position;
            startTime = Time.time;
            trackingHand = true;
            return;
        }

        // Smooth out the hand movement.
        smoothPosition = Vector3.Lerp(
            smoothPosition,
            position,
            1f - Mathf.Exp(-smoothing * Time.deltaTime)
        );

        if (!trackingHand)
        {
            startPosition = smoothPosition;
            startTime = Time.time;
            trackingHand = true;
        }

        CheckDownwardSwipe(hand.PalmVelocity);

        if (!confirmed)
            CheckHorizontalSwipe();
    }

    private Hand GetHand(Frame frame)
    {
        if (frame == null || frame.Hands.Count == 0)
            return null;

        // Keep tracking the same hand when possible.
        foreach (Hand h in frame.Hands)
        {
            if (h.Id == trackedHandId)
                return h;
        }

        return frame.Hands[0];
    }

    private void CheckDownwardSwipe(Vector3 velocity)
    {
        bool settling = Time.time - lastSwipeTime < settleAfterSwipe;
        bool falling = !settling && velocity.y < -downSwipeSpeed;

        if (falling)
        {
            lastFallingTime = Time.time;
            movingDown = true;
        }
        else if (settling || Time.time - lastFallingTime > downPauseTolerance)
        {
            movingDown = false;
        }

        // Update the starting position until the hand moves down.
        if (!movingDown)
        {
            downStartPosition = smoothPosition;
            return;
        }

        float drop = downStartPosition.y - smoothPosition.y;
        float sideways = Mathf.Abs(smoothPosition.x - downStartPosition.x);

        if (drop >= downSwipeDistance && drop > sideways * directionThreshold)
        {
            confirmed = true;
            characterSelection.ConfirmHero();
        }
    }

    private void CheckHorizontalSwipe()
    {
        if (Time.time - lastSwipeTime < cooldown)
        {
            trackingHand = false;
            return;
        }

        float elapsed = Time.time - startTime;

        if (elapsed > swipeTime)
        {
            startPosition = smoothPosition;
            startTime = Time.time;
            return;
        }

        float horizontal = smoothPosition.x - startPosition.x;
        float vertical = smoothPosition.y - startPosition.y;

        // Check the swipe direction before switching characters.
        if (Mathf.Abs(horizontal) >= swipeDistance &&
            Mathf.Abs(horizontal) > Mathf.Abs(vertical) * directionThreshold)
        {
            if (horizontal > 0f)
                characterSelection.NextHero();
            else
                characterSelection.PreviousHero();

            lastSwipeTime = Time.time;
            trackingHand = false;
            movingDown = false;
        }
    }
}
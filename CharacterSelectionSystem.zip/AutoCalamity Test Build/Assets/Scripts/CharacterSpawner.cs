
using System.Collections;
using UnityEngine;

public class CharacterSpawner : MonoBehaviour
{
    [SerializeField] private SpriteRenderer characterRenderer;

    [Header("Character Sprites")]
    [SerializeField] private Sprite knightSprite;
    [SerializeField] private Sprite pacifistSprite;
    [SerializeField] private Sprite sorcererSprite;

    [Header("Scene Fade")]
    [SerializeField] private CanvasGroup screenFade;
    [SerializeField] private float fadeDuration = 0.6f;

    private void Awake()
    {
        screenFade.alpha = 1f;
        screenFade.blocksRaycasts = true;
    }

    private void Start()
    {
        string selectedHero = PlayerPrefs.GetString(
            "SelectedHeroName", "Pacifist"
        );

        // Display the selected character.
        switch (selectedHero.Trim().ToLowerInvariant())
        {
            case "knight":
                characterRenderer.sprite = knightSprite;
                break;

            case "pacifist":
                characterRenderer.sprite = pacifistSprite;
                break;

            case "sorcerer":
                characterRenderer.sprite = sorcererSprite;
                break;

            default:
                characterRenderer.sprite = pacifistSprite;
                break;
        }

        StartCoroutine(FadeIn());
    }

    private IEnumerator FadeIn()
    {
        float time = 0f;

        while (time < fadeDuration)
        {
            time += Time.unscaledDeltaTime;
            screenFade.alpha = 1f - Mathf.Clamp01(time / fadeDuration);
            yield return null;
        }

        screenFade.alpha = 0f;
        screenFade.blocksRaycasts = false;
    }
}

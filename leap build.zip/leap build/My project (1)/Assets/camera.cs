using UnityEngine;

[RequireComponent(typeof(Camera))]
public class CameraFollow : MonoBehaviour
{
    public Transform target;
    public float yOffset = 1.5f;
    public float smoothTime = 0.15f;
    public bool followY = true;

    public float scrollSpeed = 3f;
    public float startMoveThreshold = 0.1f;
    public float edgePadding = 0.5f;
    public bool clampRightEdge = true;

    private Camera cam;
    private Rigidbody2D targetBody;
    private Vector3 startTargetPosition;
    private float yVelocity;
    private float fixedY;
    private bool scrolling;

    private void Start()
    {
        cam = GetComponent<Camera>();
        fixedY = transform.position.y;

        if (target == null)
        {
            SquareController square = FindFirstObjectByType<SquareController>();
            if (square != null)
            {
                target = square.transform;
            }
        }

        if (target != null)
        {
            targetBody = target.GetComponent<Rigidbody2D>();
            startTargetPosition = target.position;
        }
    }

    private void LateUpdate()
    {
        if (target == null)
        {
            return;
        }

        if (!scrolling && Mathf.Abs(target.position.x - startTargetPosition.x) > startMoveThreshold)
        {
            scrolling = true;
        }

        Vector3 pos = transform.position;

        if (scrolling)
        {
            pos.x += scrollSpeed * Time.deltaTime;
        }

        float desiredY = followY ? target.position.y + yOffset : fixedY;
        pos.y = Mathf.SmoothDamp(pos.y, desiredY, ref yVelocity, smoothTime);

        transform.position = pos;

        if (scrolling)
        {
            KeepTargetInFrame();
        }
    }

    private void KeepTargetInFrame()
    {
        float halfWidth = cam.orthographicSize * cam.aspect;
        float minX = transform.position.x - halfWidth + edgePadding;
        float maxX = transform.position.x + halfWidth - edgePadding;

        Vector3 p = target.position;
        float clampedX = p.x;

        if (p.x < minX)
        {
            clampedX = minX;
        }
        else if (clampRightEdge && p.x > maxX)
        {
            clampedX = maxX;
        }

        if (Mathf.Approximately(clampedX, p.x))
        {
            return;
        }

        if (targetBody != null)
        {
            Vector2 v = targetBody.linearVelocity;
            if ((clampedX == minX && v.x < 0f) || (clampedX == maxX && v.x > 0f))
            {
                v.x = 0f;
                targetBody.linearVelocity = v;
            }

            targetBody.position = new Vector2(clampedX, targetBody.position.y);
        }

        target.position = new Vector3(clampedX, p.y, p.z);
    }
}
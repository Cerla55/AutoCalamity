using UnityEngine;

[RequireComponent(typeof(Rigidbody2D))]
public class SquareController : MonoBehaviour
{
    public LeapInput input;
    public float moveSpeed = 6f;
    public float slideSpeedMultiplier = 1.5f;
    public float jumpForce = 12f;
    public float slideScaleY = 0.5f;

    [Header("Auto Run")]
    public bool autoRun = true;
    [Range(0f, 1f)] public float deadzone = 0.25f; // how far the hand must move to pick a direction
    public bool allowStop = false;                 // if true, a "stop" gesture can halt movement

    private Rigidbody2D rb;
    private Vector3 baseScale;
    private bool grounded;
    private float runDirection; // -1 = left, 0 = standing still, 1 = right

    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        baseScale = transform.localScale;
    }

    private void Start()
    {
        if (input == null)
        {
            input = FindFirstObjectByType<LeapInput>();
        }
    }

    private void FixedUpdate()
    {
        if (input == null)
        {
            return;
        }

        UpdateRunDirection();

        float speed = moveSpeed;
        if (input.Slide && grounded)
        {
            speed *= slideSpeedMultiplier;
        }

        Vector2 velocity = rb.linearVelocity;
        velocity.x = runDirection * speed;

        if (input.Jump && grounded && !input.Slide)
        {
            velocity.y = jumpForce;
        }

        rb.linearVelocity = velocity;

        float targetY = input.Slide ? baseScale.y * slideScaleY : baseScale.y;
        transform.localScale = new Vector3(baseScale.x, targetY, baseScale.z);

        grounded = false;
    }

    private void UpdateRunDirection()
    {
        if (!autoRun)
        {
            runDirection = input.Horizontal;
            return;
        }

        float h = input.Horizontal;

        // Hand moved past the deadzone: pick (or switch) direction and keep it.
        if (Mathf.Abs(h) > deadzone)
        {
            runDirection = Mathf.Sign(h);
        }
        // Otherwise keep the last direction, unless stopping is allowed.
        else if (allowStop)
        {
            runDirection = 0f;
        }
    }

    private void OnCollisionStay2D(Collision2D collision)
    {
        foreach (ContactPoint2D contact in collision.contacts)
        {
            if (contact.normal.y > 0.5f)
            {
                grounded = true;
                return;
            }
        }
    }
}
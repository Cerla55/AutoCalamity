using UnityEngine;

[RequireComponent(typeof(Rigidbody2D))]
[RequireComponent(typeof(BoxCollider2D))]
public class InfiniteGround2D : MonoBehaviour
{
    [Header("Target")]
    public Transform player;

    [Header("Size")]
    [Tooltip("Total ground width in world units. Should be much wider than the camera view.")]
    public float groundWidth = 200f;
    public float groundHeight = 2f;

    [Header("Tiling")]
    [Tooltip("Auto = use the sprite's own width (needed for Tiled draw mode so the pattern doesn't slide).")]
    public bool autoTileWidth = true;
    public float tileWidth = 1f;

    private Rigidbody2D rb;
    private BoxCollider2D box;
    private SpriteRenderer sr;

    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        box = GetComponent<BoxCollider2D>();
        sr = GetComponent<SpriteRenderer>();

        rb.bodyType = RigidbodyType2D.Kinematic;
        rb.interpolation = RigidbodyInterpolation2D.None;
        rb.useFullKinematicContacts = true;

        SetupSize();
    }

    private void Start()
    {
        if (player == null)
        {
            SquareController sc = FindFirstObjectByType<SquareController>();
            if (sc != null) player = sc.transform;
        }

        if (player == null)
            Debug.LogError("InfiniteGround2D: no player found. Assign the Player field.", this);
    }

    private void SetupSize()
    {
        if (sr != null && sr.sprite != null)
        {
            // Tiled mode: size is set on the renderer, so keep the transform scale at 1.
            if (sr.drawMode != SpriteDrawMode.Tiled)
                sr.drawMode = SpriteDrawMode.Tiled;

            transform.localScale = Vector3.one;
            sr.size = new Vector2(groundWidth, groundHeight);

            if (autoTileWidth)
                tileWidth = sr.sprite.bounds.size.x;
        }
        else
        {
            // No sprite: use the transform scale to size a plain object.
            transform.localScale = new Vector3(groundWidth, groundHeight, 1f);
        }

        if (tileWidth <= 0.0001f) tileWidth = 1f;

        // Collider is in local space; with scale 1 this matches the visual.
        if (sr != null && sr.sprite != null)
        {
            box.size = new Vector2(groundWidth, groundHeight);
            box.offset = Vector2.zero;
        }
    }

    private void FixedUpdate()
    {
        if (player == null) return;

        float x = Mathf.Round(player.position.x / tileWidth) * tileWidth;
        rb.position = new Vector2(x, rb.position.y);
    }
}
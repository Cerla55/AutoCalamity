using System.IO;
using UnityEngine;

public class SaveSystem : MonoBehaviour
{
    // This script is used to save and load game data using the SaveData class.
    static string SavePath => Path.Combine(Application.persistentDataPath, "save.json");

    public static bool HasSaveData()
    {
        return File.Exists(SavePath);
    }

    public static void SaveGame(SaveData data)
    {
        string json = JsonUtility.ToJson(data);
        File.WriteAllText(SavePath, json);
        Debug.Log("Game saved to: " + SavePath);
    }

    public static SaveData LoadGame()
    {
        if (!HasSaveData())
        {
            Debug.LogWarning("No save data found.");
            return null;
        }
        string json = File.ReadAllText(SavePath);
        SaveData data = JsonUtility.FromJson<SaveData>(json);
        Debug.Log("Game loaded from: " + SavePath);
        return data;
    }

    public static class GameSession
    {
        public static SaveSystem current;
    }
}

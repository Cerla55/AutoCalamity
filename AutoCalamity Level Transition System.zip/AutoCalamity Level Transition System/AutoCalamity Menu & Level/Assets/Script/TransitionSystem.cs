using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using TMPro;

public class TransitionSystem : MonoBehaviour
{
    public static TransitionSystem Instance { get; private set; }
    //MAIN MENU
    public GameObject mainMenu;
    public Button playButton;
    public Button optionsButton;
    public Button quitButton;

    // GAMELOADER
    public GameObject gameLoader;
    public Button newGameButton;
    public Button continueGameButton;
    public Button loadGameButton;
    public Button exitGameLoaderButton;

    // OPTIONS/SETTINGS
    public GameObject optionsSettings;
    public Button exitOptionsButton;

    // This script is used to manage the transition between scenes and handle button requests in the main menu, game loader, and options/settings.

    //MAIN MENU
    public void PlayButton()
    {
        Debug.Log("Play Button has been requested.");
        mainMenu.SetActive(false); //Close Main Menu
        gameLoader.SetActive(true); //Open Game Loader
    }

    public void OptionsButton()
    {
        Debug.Log("Options Button has been requested.");
        mainMenu.SetActive(false); //Close Main Menu
        optionsSettings.gameObject.SetActive(true); //Open Options/Settings
    }

    public void QuitButton()
    {
        Debug.Log("Quit Game has been requested.");
        Application.Quit();
    }

    // GAMELOADER
    public void NewGameButton()
    {
        Debug.Log("New Game has been requested.");
        SceneManager.LoadSceneAsync(1);
    }

    public void ContinueGameButton()
    {
        Debug.Log("Continue Game has been requested.");
    }   

    public void LoadGameButton()
    {
        Debug.Log("Load Game has been requested.");
    }

    public void BackMenuButton()
    {
        Debug.Log("Back to Menu has been requested.");
        gameLoader.SetActive(false); //Close Game Loader
        mainMenu.SetActive(true); //Open Main Menu
    }

    // OPTIONS/SETTINGS
    public void ExitOptionsButton()
    {
        Debug.Log("Exiting Options has been requested.");
        optionsSettings.SetActive(false); //Close Options/Settings
        mainMenu.SetActive(true); //Open Main Menu
    }

    //TRANSITION TO GAME
    public void LoadGameScene()
    {
        Debug.Log("Play Game has been requested.");
        SceneManager.LoadSceneAsync(1);
    }
}

using UnityEngine;

public class ShieldAttack : MonoBehaviour, IAttack
{
    public float duration = 2f;
    public float cooldown = 5f;
    public Vector2 size = new Vector2(1.6f, 1.6f);
    public Color color = new Color(0.3f, 0.8f, 1f, 0.35f);

    public bool Active { get; private set; }

    private float endTime;
    private float nextTime;
    private Transform target;
    private GameObject visual;

    public bool TryActivate(Transform owner, int facing)
    {
        if (Time.time < nextTime)
            return false;

        nextTime = Time.time + cooldown;
        endTime = Time.time + duration;
        target = owner;
        Active = true;

        if (visual == null)
            visual = BuildVisual();

        visual.transform.position = target.position;
        visual.SetActive(true);
        return true;
    }

    private void Update()
    {
        if (!Active)
            return;

        if (target != null)
            visual.transform.position = target.position;

        if (Time.time >= endTime)
        {
            Active = false;
            visual.SetActive(false);
        }
    }

    private GameObject BuildVisual()
    {
        GameObject go = new GameObject("ShieldVisual");
        go.transform.localScale = new Vector3(size.x, size.y, 1f);

        SpriteRenderer sr = go.AddComponent<SpriteRenderer>();
        sr.sprite = AttackHitbox.GetSquare();
        sr.color = color;
        sr.sortingOrder = 99;
        return go;
    }

    private void OnDestroy()
    {
        if (visual != null)
            Destroy(visual);
    }
}
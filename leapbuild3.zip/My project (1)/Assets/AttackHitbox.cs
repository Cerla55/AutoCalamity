using System.Collections.Generic;
using UnityEngine;

public class AttackHitbox : MonoBehaviour
{
    [HideInInspector] public int damage = 1;
    [HideInInspector] public float lifetime = 0.2f;
    [HideInInspector] public Vector2 velocity;
    [HideInInspector] public bool destroyOnHit;
    [HideInInspector] public Transform owner;
    [HideInInspector] public Transform follow;
    [HideInInspector] public Vector2 followOffset;

    private static Sprite squareSprite;
    private readonly HashSet<Collider2D> alreadyHit = new HashSet<Collider2D>();

    public static AttackHitbox Create(Vector2 center, Vector2 size, Color color)
    {
        GameObject go = new GameObject("AttackHitbox");
        go.transform.position = center;
        go.transform.localScale = new Vector3(size.x, size.y, 1f);

        SpriteRenderer sr = go.AddComponent<SpriteRenderer>();
        sr.sprite = GetSquare();
        sr.color = color;
        sr.sortingOrder = 100;

        BoxCollider2D box = go.AddComponent<BoxCollider2D>();
        box.isTrigger = true;
        box.size = Vector2.one;

        Rigidbody2D rb = go.AddComponent<Rigidbody2D>();
        rb.bodyType = RigidbodyType2D.Kinematic;
        rb.gravityScale = 0f;

        return go.AddComponent<AttackHitbox>();
    }

    public static Sprite GetSquare()
    {
        if (squareSprite != null)
            return squareSprite;

        Texture2D tex = new Texture2D(1, 1);
        tex.SetPixel(0, 0, Color.white);
        tex.Apply();
        squareSprite = Sprite.Create(tex, new Rect(0, 0, 1, 1), new Vector2(0.5f, 0.5f), 1f);
        return squareSprite;
    }

    private void Start()
    {
        Destroy(gameObject, lifetime);
    }

    private void Update()
    {
        if (follow != null)
            transform.position = (Vector2)follow.position + followOffset;

        transform.position += (Vector3)(velocity * Time.deltaTime);
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (owner != null && (other.transform == owner || other.transform.IsChildOf(owner)))
            return;

        if (!alreadyHit.Add(other))
            return;

        IDamageable target = other.GetComponentInParent<IDamageable>();
        if (target != null)
        {
            target.TakeDamage(damage);
            if (destroyOnHit)
                Destroy(gameObject);
        }
    }
}
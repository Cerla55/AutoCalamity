using Unity.VisualScripting.FullSerializer;
using UnityEngine;

public class AnimParamResetter : StateMachineBehaviour
{
    [SerializeField] string[] paramNames;   // List of Params to Reset, for arbitrary parameter names

    private string[] animParams =           // Generic Parameter Names
    {
        "Plyr-Sld",     // Player Slide
        "Plyr-Jmp",     // Player Jumping
        "Plyr-Atk",     // Player Ability
    };

    // Override OnStateExit
    public override void OnStateExit(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
        // This was auto-entered from Visual Studio
        base.OnStateExit(animator, stateInfo, layerIndex);

        for (int i = 0; i < paramNames.Length; i++)
        {
            animator.SetBool(paramNames[i], false);
        }

        for (int i = 0; i < animParams.Length; i++)
        {
            animator.SetBool(animParams[i], false);
            //Debug.Log(i);
        }
        //AnimatorStateInfo altInfo = animator.GetCurrentAnimatorStateInfo(0);
        Debug.Log("Time Exited Animation: " + stateInfo.normalizedTime.ToString());
    }
}

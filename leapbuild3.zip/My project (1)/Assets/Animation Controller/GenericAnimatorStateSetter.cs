using UnityEngine;

public class GenericAnimatorStateSetter : MonoBehaviour
{
    /*****
     * Generic Animator Parameter Sender
     *  By Alexander Sotelo
     *  V0.1.0
     * Essentially, a debug script to pass parameters to a given Animator
     * Could also be modified to allow the Leap Motion to assign to a particular parameter based on input.
     *****
     */


    [SerializeField] Animator anim;
    [SerializeField] PlayerCharacterNames charPlayer;

    // Player Character in use
    enum PlayerCharacterNames
    {
        Knight,
        Sorcerer,
        Pacifist,
    };

    // Player Abilities, as Animator State Names
    private string[] abilityAnimStateNames =
    {
        "SwordSlice",
        "MagicExplosion",
        "Parry",
    };

    [SerializeField] bool isSlide = false;
    [SerializeField] bool isJump = false;
    [SerializeField] bool isAbility = false;
    bool hasJumped = false; // If player has jumped, or has fallen off (i.e. in-air)


    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        if (anim == null)
        {
            anim = GetComponent<Animator>();
        }
    }

    // Update is called once per frame
    void Update()
    {
        AnimatorStateInfo stateInfo = anim.GetCurrentAnimatorStateInfo(0);  // Note: 0 is Base Layer (required)

        if (stateInfo.IsName("Run"))
        {
            anim.SetBool("Plyr-Sld", isSlide);
            anim.SetBool("Plyr-Jmp", isJump);
            anim.SetBool("Plyr-Atk", isAbility);
            //Debug.Log("Animation Time " + stateInfo.normalizedTime.ToString());
        }
        // Note that we probably don't *need* to constantly set the booleans for these outside of the Debug Activate (Unity Editor)
        // They are just here to make sure only one thing runs, the real Leap Motion Inputter may just call an actual method to do this.
        else if (stateInfo.IsName(abilityAnimStateNames[(int)charPlayer]))
        {
            isSlide = false;
            isJump = false;

            isAbility = anim.GetBool("Plyr-Atk");
            //Debug.Log("Animation Time " + stateInfo.normalizedTime.ToString());
        }
        else if (stateInfo.IsName("Slide"))
        {
            isJump = false;
            isAbility = false;

            isSlide = anim.GetBool("Plyr-Sld");
            //Debug.Log("Animation Time " + stateInfo.normalizedTime.ToString());
        }
        else if (stateInfo.IsName("Jump"))
        {
            isSlide = false;
            isAbility = false;

            hasJumped = true;
            //Debug.Log("Animation Time " + stateInfo.normalizedTime.ToString());
        }

        // Note: 1 unit is a full Animation Clip
        // TODO: Maybe reduce the second condition? Need more testing
        if (stateInfo.normalizedTime >= 0.9f && stateInfo.normalizedTime <= 1.3f)
        {
            //isSlide = anim.GetBool("Plyr-Sld");
            //isJump = anim.GetBool("Plyr-Jmp");
            //isAbility = anim.GetBool("Plyr-Atk");
            isSlide = false;
            isJump = false;
            isAbility = false;
        }
    }

    // Just some generic methods to set the Boolean for the Anim Param and also this local boolean
    // Mostly for the Physics/Input Handler to call whenever an action is needed
    // Animator States go back to the "Run" State around the time the Clip finishes running, which will
    //  auto-reset all of these Variables, useful for knowing if we can re-apply certain inputs later
    public void SetSlideAnimBoolAndState(bool val)
    {
        isSlide = val;
        anim.SetBool("Plyr-Sld", val);
    }
    public void SetJumpAnimBoolAndState(bool val)
    {
        isJump = val;
        anim.SetBool("Plyr-Jmp", val);
    }
    public void SetAbilityAnimBoolAndState(bool val)
    {
        isAbility = val;
        anim.SetBool("Plyr-Atk", val);
    }
}

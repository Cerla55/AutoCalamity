using System;
using UnityEngine;
using Leap;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

public class LeapInput : MonoBehaviour
{
    public enum PreferredHand { Any, Left, Right }
    public enum AttackType { None, Attack1, Attack2, Attack3 }

    [Header("Tracking")]
    public LeapProvider provider;
    public PreferredHand preferredHand = PreferredHand.Any;
    [Tooltip("Seconds of lost tracking to ride out before input is cleared.")]
    public float lostGraceTime = 0.15f;
    [Tooltip("If tracking is lost longer than this, the neutral point is re-captured on return.")]
    public float recalibrateAfterLost = 1.0f;

    [Header("Horizontal (meters)")]
    public float horizontalDeadzone = 0.05f;
    public float horizontalRange = 0.15f;
    [Tooltip("1 = linear. Higher values give finer control near center.")]
    public float horizontalCurve = 1.5f;

    [Header("Vertical (meters)")]
    public float jumpHeight = 0.08f;
    public float slideHeight = 0.08f;
    [Tooltip("How far back toward neutral the hand must come to release jump/slide.")]
    public float verticalHysteresis = 0.02f;

    [Header("Smoothing")]
    [Tooltip("Higher = snappier, lower = smoother. 0 disables smoothing.")]
    public float smoothing = 18f;

    [Header("Attack")]
    [Range(0f, 1f)] public float fistThreshold = 0.85f;
    [Range(0f, 1f)] public float fistReleaseThreshold = 0.6f;
    public float attackCooldown = 0.4f;
    public GameObject attack1;
    public GameObject attack2;
    public GameObject attack3;
    public AttackType selectedAttack = AttackType.Attack1;

    public float Horizontal { get; private set; }
    public bool Jump { get; private set; }
    public bool Slide { get; private set; }
    public bool HandPresent { get; private set; }
    public bool Fist { get; private set; }

    public bool JumpPressed { get; private set; }
    public bool SlidePressed { get; private set; }
    public bool AttackPressed { get; private set; }
    public AttackType CurrentAttack { get; private set; }

    public event Action<AttackType, GameObject> OnAttack;

    private Vector3 neutral;
    private Vector3 smoothedPalm;
    private bool calibrated;
    private float lostTimer;
    private float nextAttackTime;

    private void Update()
    {
        JumpPressed = false;
        SlidePressed = false;
        AttackPressed = false;

        if (provider == null)
        {
            provider = FindFirstObjectByType<LeapProvider>();
            if (provider == null)
            {
                ClearInput();
                return;
            }
        }

        Hand hand = GetHand(provider.CurrentFrame);

        if (hand == null)
        {
            lostTimer += Time.deltaTime;

            if (lostTimer > lostGraceTime)
                ClearInput();

            if (lostTimer > recalibrateAfterLost)
                calibrated = false;

            return;
        }

        lostTimer = 0f;
        HandPresent = true;

        Vector3 palm = hand.PalmPosition;

        if (!calibrated || RecalibratePressed())
        {
            neutral = palm;
            smoothedPalm = palm;
            calibrated = true;
        }

        if (smoothing > 0f)
        {
            float t = 1f - Mathf.Exp(-smoothing * Time.deltaTime);
            smoothedPalm = Vector3.Lerp(smoothedPalm, palm, t);
        }
        else
        {
            smoothedPalm = palm;
        }

        Vector3 offset = smoothedPalm - neutral;

        Horizontal = ComputeHorizontal(offset.x);
        UpdateVertical(offset.y);
        UpdateAttack(hand.GrabStrength);
    }

    private Hand GetHand(Frame frame)
    {
        if (frame == null || frame.Hands.Count == 0)
            return null;

        if (preferredHand == PreferredHand.Any)
            return frame.Hands[0];

        bool wantLeft = preferredHand == PreferredHand.Left;
        foreach (Hand h in frame.Hands)
        {
            if (h.IsLeft == wantLeft)
                return h;
        }

        return null;
    }

    private float ComputeHorizontal(float x)
    {
        float abs = Mathf.Abs(x);
        if (abs <= horizontalDeadzone)
            return 0f;

        float span = Mathf.Max(horizontalRange - horizontalDeadzone, 0.0001f);
        float normalized = Mathf.Clamp01((abs - horizontalDeadzone) / span);
        float curved = Mathf.Pow(normalized, horizontalCurve);

        return Mathf.Sign(x) * curved;
    }

    private void UpdateVertical(float y)
    {
        bool jumpNow = Jump
            ? y > jumpHeight - verticalHysteresis
            : y > jumpHeight;

        bool slideNow = Slide
            ? y < -(slideHeight - verticalHysteresis)
            : y < -slideHeight;

        JumpPressed = jumpNow && !Jump;
        SlidePressed = slideNow && !Slide;

        Jump = jumpNow;
        Slide = slideNow;
    }

    private void UpdateAttack(float grabStrength)
    {
        bool fistNow = Fist
            ? grabStrength > fistReleaseThreshold
            : grabStrength > fistThreshold;

        bool started = fistNow && !Fist;
        Fist = fistNow;

        if (!started || Time.time < nextAttackTime)
            return;

        nextAttackTime = Time.time + attackCooldown;
        AttackPressed = true;

        CurrentAttack = selectedAttack;
        OnAttack?.Invoke(CurrentAttack, GetAttack(CurrentAttack));
    }

    public GameObject GetAttack(AttackType type)
    {
        switch (type)
        {
            case AttackType.Attack1: return attack1;
            case AttackType.Attack2: return attack2;
            case AttackType.Attack3: return attack3;
            default: return null;
        }
    }

    public void SetAttack(AttackType type)
    {
        selectedAttack = type;
    }

    public void Recalibrate()
    {
        calibrated = false;
    }

    private bool RecalibratePressed()
    {
#if ENABLE_INPUT_SYSTEM
        return Keyboard.current != null && Keyboard.current.rKey.wasPressedThisFrame;
#else
        return Input.GetKeyDown(KeyCode.R);
#endif
    }

    private void ClearInput()
    {
        HandPresent = false;
        Horizontal = 0f;
        Jump = false;
        Slide = false;
        Fist = false;
    }
}
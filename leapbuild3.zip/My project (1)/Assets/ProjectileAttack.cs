using UnityEngine;

public class ProjectileAttack : MonoBehaviour, IAttack
{
    public Vector2 size = new Vector2(0.8f, 0.3f);
    public float spawnOffset = 0.6f;
    public float speed = 25f;
    public float lifetime = 2f;
    public int damage = 1;
    public float cooldown = 0.5f;
    public Color color = new Color(1f, 0f, 0f, 0.5f);

    private float nextTime;

    public bool TryActivate(Transform owner, int facing)
    {
        if (Time.time < nextTime)
            return false;

        nextTime = Time.time + cooldown;

        Vector2 spawn = (Vector2)owner.position + new Vector2(facing * spawnOffset, 0f);

        AttackHitbox hb = AttackHitbox.Create(spawn, size, color);
        hb.damage = damage;
        hb.lifetime = lifetime;
        hb.velocity = new Vector2(facing * speed, 0f);
        hb.destroyOnHit = true;
        hb.owner = owner;
        return true;
    }
}
using UnityEngine;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

public class PlayerAttacks : MonoBehaviour
{
    public LeapInput input;

    private int facing = 1;
    private ShieldAttack shield;

    public bool Invulnerable
    {
        get { return shield != null && shield.Active; }
    }

    private void OnEnable()
    {
        if (input == null)
            input = GetComponent<LeapInput>();
        if (input == null)
            input = FindFirstObjectByType<LeapInput>();

        if (input != null)
        {
            input.OnAttack += HandleAttack;
            if (input.attack1 != null)
                shield = input.attack1.GetComponent<ShieldAttack>();
        }
    }

    private void OnDisable()
    {
        if (input != null)
            input.OnAttack -= HandleAttack;
    }

    private void Update()
    {
        if (input != null && Mathf.Abs(input.Horizontal) > 0.1f)
            facing = input.Horizontal > 0f ? 1 : -1;

        HandleKeySelect();
    }

    private void HandleAttack(LeapInput.AttackType type, GameObject attackObject)
    {
        if (attackObject == null)
            return;

        IAttack attack = attackObject.GetComponent<IAttack>();
        if (attack != null)
            attack.TryActivate(transform, facing);
    }

    private void HandleKeySelect()
    {
        if (input == null)
            return;

#if ENABLE_INPUT_SYSTEM
        Keyboard kb = Keyboard.current;
        if (kb == null)
            return;

        if (kb.digit1Key.wasPressedThisFrame) input.SetAttack(LeapInput.AttackType.Attack1);
        if (kb.digit2Key.wasPressedThisFrame) input.SetAttack(LeapInput.AttackType.Attack2);
        if (kb.digit3Key.wasPressedThisFrame) input.SetAttack(LeapInput.AttackType.Attack3);
#else
        if (Input.GetKeyDown(KeyCode.Alpha1)) input.SetAttack(LeapInput.AttackType.Attack1);
        if (Input.GetKeyDown(KeyCode.Alpha2)) input.SetAttack(LeapInput.AttackType.Attack2);
        if (Input.GetKeyDown(KeyCode.Alpha3)) input.SetAttack(LeapInput.AttackType.Attack3);
#endif
    }
}
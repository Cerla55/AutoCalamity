using UnityEngine;

public class SlashAttack : MonoBehaviour, IAttack
{
    public Vector2 size = new Vector2(3.5f, 0.9f);
    public float offset = 0.4f;
    public float duration = 0.15f;
    public int damage = 2;
    public float cooldown = 0.5f;
    public Color color = new Color(1f, 0f, 0f, 0.5f);

    private float nextTime;

    public bool TryActivate(Transform owner, int facing)
    {
        if (Time.time < nextTime)
            return false;

        nextTime = Time.time + cooldown;

        Vector2 localOffset = new Vector2(facing * (offset + size.x * 0.5f), 0f);

        AttackHitbox hb = AttackHitbox.Create((Vector2)owner.position + localOffset, size, color);
        hb.damage = damage;
        hb.lifetime = duration;
        hb.owner = owner;
        hb.follow = owner;
        hb.followOffset = localOffset;
        return true;
    }
}
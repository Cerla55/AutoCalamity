using UnityEngine;

public interface IAttack
{
    bool TryActivate(Transform owner, int facing);
}
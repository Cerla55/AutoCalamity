using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    public Transform target;
    public Vector2 offset = new Vector2(0f, 1.5f);
    public float smoothTime = 0.15f;
    public bool followY = true;

    private Vector3 velocity;
    private float fixedY;

    private void Start()
    {
        fixedY = transform.position.y;

        if (target == null)
        {
            SquareController square = FindFirstObjectByType<SquareController>();
            if (square != null)
            {
                target = square.transform;
            }
        }
    }

    private void LateUpdate()
    {
        if (target == null)
        {
            return;
        }

        float y = followY ? target.position.y + offset.y : fixedY;
        Vector3 desired = new Vector3(target.position.x + offset.x, y, transform.position.z);

        transform.position = Vector3.SmoothDamp(transform.position, desired, ref velocity, smoothTime);
    }
}